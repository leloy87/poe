﻿namespace CldvExample.wwwroot.css
{
    public class responsive
    {
    }
}
